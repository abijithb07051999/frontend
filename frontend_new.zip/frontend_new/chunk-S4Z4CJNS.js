import"./chunk-TSRGIXR5.js";var t=[{path:"",loadComponent:()=>import("./chunk-3QGVYXZD.js").then(o=>o.CompanyMasterComponent)}];export{t as companyMasterRoutes};
