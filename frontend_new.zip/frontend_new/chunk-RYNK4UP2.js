import"./chunk-TSRGIXR5.js";var n=[{path:"",loadComponent:()=>import("./chunk-BDTXIW44.js").then(o=>o.AdminVerificationComponent)}];export{n as adminVerificationRoutes};
