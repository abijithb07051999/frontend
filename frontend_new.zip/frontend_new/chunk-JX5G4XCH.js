import"./chunk-TSRGIXR5.js";var t=[{path:"",loadComponent:()=>import("./chunk-XPV4DBO6.js").then(o=>o.CustomerAllocationComponent)}];export{t as costomerAllocationRoutes};
