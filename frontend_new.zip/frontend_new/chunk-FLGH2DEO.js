var t={apiUrl:"http://103.14.120.59"};export{t as a};
