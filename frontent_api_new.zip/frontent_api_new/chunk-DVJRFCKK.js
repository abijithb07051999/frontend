import"./chunk-TSRGIXR5.js";var t=[{path:"",loadComponent:()=>import("./chunk-W3AKYBV4.js").then(o=>o.CustomerAllocationComponent)}];export{t as costomerAllocationRoutes};
