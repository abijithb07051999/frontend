import"./chunk-TSRGIXR5.js";var n=[{path:"",loadComponent:()=>import("./chunk-W5QX56VX.js").then(o=>o.AdminVerificationComponent)}];export{n as adminVerificationRoutes};
