var p={apiUrl:"http://103.14.120.59/api"};export{p as a};
