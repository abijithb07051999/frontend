import"./chunk-TSRGIXR5.js";var t=[{path:"",loadComponent:()=>import("./chunk-SWSHQLPP.js").then(o=>o.OfficeVerificationComponent)}];export{t as officeVerificationRoutes};
